from django.apps import AppConfig


class CprojectConfig(AppConfig):
    name = 'cproject'
